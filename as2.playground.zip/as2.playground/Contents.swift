// Assignment 2: Working with Collections in Swift

// Task 1: Array Creation and Access

var fruits: [String] = ["Apple", "Banana", "Cherry", "Mango", "Grape"]
print("Third fruit: \(fruits[2])")

// Task 2: Set Creation and Manipulation

var favoriteNumbers: Set<Int> = [7, 27, 13, 21]
favoriteNumbers.insert(9)
print("Updated set of favorite numbers: \(favoriteNumbers)")

// Task 3: Dictionary Creation and Access

var languageReleaseYears: [String: Int] = [
    "Swift": 2014,
    "Python": 1991,
    "Java": 1995
]
print("Swift was released in \(languageReleaseYears["Swift"]!)")

// Task 4: Array Element Update

var colors: [String] = ["Red", "Green", "Blue", "Yellow"]
colors[1] = "Purple"
print("Updated colors: \(colors)")

// Mid Task 1: Set Intersection

let setA: Set<Int> = [1, 2, 3, 4]
let setB: Set<Int> = [3, 4, 5, 6]
let intersection = setA.intersection(setB)
print("Intersection of setA and setB: \(intersection)")

// Mid Task 2: Dictionary Update

var studentScores: [String: Int] = [
    "Nurbolat": 85,
    "Aigerim": 92,
    "Daniyar": 78
]
studentScores.updateValue(95, forKey: "Nurbolat")
print("Updated student scores: \(studentScores)")

// Mid Task 3: Array Merge

let fruitsPart1: [String] = ["apple", "banana"]
let fruitsPart2: [String] = ["cherry", "date"]
let mergedFruits = fruitsPart1 + fruitsPart2
print("Merged fruits array: \(mergedFruits)")

// Hard Task 1: Dictionary Key Addition

var countryPopulations: [String: Int] = [
    "Kazakhstan": 19_800_000,
    "USA": 331_000_000,
    "Japan": 125_000_000
]
countryPopulations["Germany"] = 83_000_000
print("Updated country populations: \(countryPopulations)")

// Hard Task 2: Set Union and Subtract

let animalsSet1: Set<String> = ["cat", "dog"]
let animalsSet2: Set<String> = ["dog", "mouse"]
let unionResult = animalsSet1.union(animalsSet2)
let finalSet = unionResult.subtracting(animalsSet2)
print("Final set after union and subtract: \(finalSet)")

//  Hard Task 3: Nested Collection

var studentGrades: [String: [Int]] = [
    "Nurbolat": [88, 91, 76],
    "Aigerim": [95, 89, 100]
]
print("Nurbolat's second grade: \(studentGrades["Nurbolat"]![1])")
